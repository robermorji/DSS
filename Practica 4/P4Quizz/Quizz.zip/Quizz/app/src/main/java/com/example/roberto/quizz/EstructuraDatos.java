package com.example.roberto.quizz;

import java.util.Vector;

/**
 * Created by roberto on 20/01/2016.
 * Class para encapsular todas las operaciones que realizo con la estructura de Datos de mi aplicación.
 * Métodos: GetRespuestaCorrecta, GetTipoPregunta, EliminarPregunta, OrganizarRespuestas,
 * AlgoritmoBarajaPreguntas
 *
 */
public class EstructuraDatos implements Datos {

    String GetRespuestaCorrecta(Vector<String> respuestas) {

        return respuestas.get(1);
    }

    String GetTipoPregunta(Vector<String> fila){

        return fila.get(5);
    }

    public Vector<String> EliminarPregunta(Vector<String> respuestas) {
        Vector<String> auxVector = new Vector<>();
        for (int i = 1; i < 5; i++) {
            auxVector.add(0, respuestas.get(i));
        }
        return auxVector;
    }

    public Vector<String> OrganizarRespuestas(Vector<String> bat) {
        Vector<Integer> posiciones_salidas = new Vector<Integer>();
        boolean seEncuentra;
        int orden_baraja;
        for (int i = 0; i < 4; ) {
            orden_baraja = (int) (Math.random() * 4);
            seEncuentra = false;
            for (int c = 0; c < posiciones_salidas.size() && seEncuentra == false; c++) {
                if (posiciones_salidas.get(c) == orden_baraja)
                    seEncuentra = true;
            }
            if (seEncuentra != true) {
                posiciones_salidas.add(orden_baraja);
                i++;
            }
        }
        bat = AlgoritmoBarajaPreguntas(posiciones_salidas, bat);

        return bat;
    }

    public Vector<String> AlgoritmoBarajaPreguntas(Vector<Integer> posicion_cambio, Vector<String> respuestas) {
        Vector<String> respuestasBarajadas = new Vector<>();
        int posCambio;
        for (int i = 0; i < 4; i++)
            respuestasBarajadas.add(i, "0");

        for (int i = 0; i < 4; i++) {
            posCambio = posicion_cambio.get(i);
            respuestasBarajadas.set(posCambio, respuestas.get(i));
        }

        return respuestasBarajadas;
    }


}
