package com.example.roberto.quizz;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;

/**
 * Created by roberto on 19/01/2016.
 */
public class DialogoResultadoFinal extends DialogFragment {
    int numeroAciertos;
    int numeroErrores;
    int numeroPartida;
    AdaptadorDB ad;

    public void asignarResultado(int acierto, int errores, int numeroPartida){
        this.numeroAciertos = acierto;
        this.numeroErrores = errores;
        this.numeroPartida = numeroPartida;
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity());

        builder.setMessage("FINAL DEL JUEGO \nResultados\n" +
                "\nNumero de Partida: "+ this.numeroPartida +
                "\nNumero de Aciertos: " + this.numeroAciertos +
                "\nNumero de Errores:  " + this.numeroErrores)
                .setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        ad = new AdaptadorDB(getContext());
                        Activity act = getActivity();
                        Intent intent = new Intent(act, MainActivity.class);
                        intent.putExtra("NumeroAciertos", numeroAciertos);
                        intent.putExtra("NumeroErrores", numeroErrores);
                        intent.putExtra("NumeroPartida", numeroPartida);
                        ad.InsertarResultados(numeroAciertos, numeroErrores, numeroPartida);
                        startActivity(intent);
                        act.finish();
                        //dialog.cancel();
                    }
                });

        return builder.create();
    }

    public void showDialogResultado(FragmentManager fm, DialogoResultadoFinal dialogoResultadoPositivo, int numeroAciertos, int numeroErrores, int numeroPartida){
        this.asignarResultado(numeroAciertos,numeroErrores,numeroPartida);
        this.show(fm, "TagAlerta");
    }

}
