package com.example.roberto.quizz;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;

/**
 * Created by roberto on 18/01/2016.
 */
public class DialogoResultadoNegativo  extends DialogFragment {

    int numeroAciertos;
    int numeroErrores;
    int numeroPartida;

    public void asignarResultado(int acierto, int errores, int numeroPartida){
        this.numeroAciertos = acierto;
        this.numeroErrores = errores;
        this.numeroPartida = numeroPartida;
    }


    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity());

        builder.setMessage("Lo sentimos has fallado la respuesta")
                .setPositiveButton("CONTINUAR", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                })
                .setNegativeButton("TERMINAR",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog,int id){
                        Activity act= getActivity();
                        FragmentManager fm = getFragmentManager();
                        DialogoResultadoFinal resultadoFinal = new DialogoResultadoFinal();
                        resultadoFinal.asignarResultado(numeroAciertos,numeroErrores, numeroPartida);
                        resultadoFinal.show(fm,"TagAlerta");

                        //act.finish();
                        dialog.cancel();
                    }
                });


        return builder.create();
    }

    public void showDialogNegativo(FragmentManager fm, DialogoResultadoNegativo dialogoResultadoPositivo,int numeroAciertos, int numeroErrores, int numeroPartida){
        this.asignarResultado(numeroAciertos,numeroErrores, numeroPartida);
        this.show(fm,"TagAlerta");
    }
}

