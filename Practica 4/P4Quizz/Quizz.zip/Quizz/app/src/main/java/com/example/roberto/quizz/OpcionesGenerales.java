package com.example.roberto.quizz;

/**
 * Created by roberto on 21/01/2016.
 */
public interface OpcionesGenerales {

}
