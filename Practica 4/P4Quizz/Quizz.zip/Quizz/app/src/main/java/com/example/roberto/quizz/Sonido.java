package com.example.roberto.quizz;

import android.content.Context;
import android.media.MediaPlayer;

/**
 * Created by roberto on 20/01/2016.
 */
public class Sonido implements Media {

    final static int sonidoPreguntaAcertada = R.raw.aplausos_4;
    final static int sonidoPreguntaErronea  = R.raw.abucheos;
    String nombre_sonido;

    public void reproduccionsonidoPregunta ( Context context, int d) {
        MediaPlayer media = MediaPlayer.create(context, d);
        media.start();

    }

    public void seleccionArchivoSonidoPregunta (Context context, String correcta){

        nombre_sonido = correcta.toLowerCase();
        int id_sonido = context.getResources().getIdentifier("raw/" + nombre_sonido, null, context.getPackageName());
        reproduccionsonidoPregunta(context,id_sonido);
    }
    public void reproduccionSonidoAcertada ( Context context) {
        MediaPlayer media = MediaPlayer.create(context, sonidoPreguntaAcertada);
        media.start();
        try {
            Thread.sleep(1500);
        } catch (Exception e) {

        }
        media.pause();
    }

    public void reproduccionSonidoErronea ( Context context) {
        MediaPlayer media = MediaPlayer.create(context, sonidoPreguntaErronea);
        media.start();
        try {
            Thread.sleep(1500);
        } catch (Exception e) {

        }
        media.pause();
    }

}
