package com.example.roberto.quizz;


import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Vector;

public class ActivityPantallaJuego extends AppCompatActivity {
    Context context;
    ArrayList<Vector> bateriaPreguntas;
    Vector<String> vectorPreguntas;
    Vector<String> vectorRespuestas;
    Sonido objSonido;
    String seleccion;
    String correcta;
    Intent intent;
    int numeroAciertos;
    int numeroErrores;
    int seleccionar_pregunta;
    int numeroPartida;
    int numero_pregunta;
    OpcionesJuego pantalla;
    AdaptadorDB adaptadorDB;
    TextView pregunta;
    TextView TextView_numeroPregunta;
    ImageView  imagen;
    Button opcion1;
    Button opcion2;
    Button opcion3;
    Button opcion4;
    DialogoResultadoPositivo dialogoResultadoPositivo;
    DialogoResultadoNegativo dialogoResultadoNegativo;
    DialogoResultadoFinal dialogoResultadoFinal;
    FragmentManager fm;
    MediaPlayer md = new MediaPlayer();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Inicialiazación de todas las variables a usar
        numero_pregunta = 1;
        this.context = getApplicationContext();
        adaptadorDB = new AdaptadorDB(context);
        objSonido = new Sonido();
        dialogoResultadoFinal = new DialogoResultadoFinal();
        dialogoResultadoNegativo = new DialogoResultadoNegativo();
        dialogoResultadoPositivo = new DialogoResultadoPositivo();
        pantalla = new OpcionesJuego();
        bateriaPreguntas = new ArrayList<>();
        vectorPreguntas  = new Vector<>();
        vectorRespuestas = new Vector<>();
        fm = getSupportFragmentManager();
        seleccionar_pregunta = 0;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_pantalla_juego);

        intent = getIntent();
        // Intent para llevar el contador del número de la partida
        if(intent!=null){
            Bundle bundle = intent.getExtras();
            numeroPartida = bundle.getInt("numero_partida");
        }
        else{
            numeroPartida = 1;
        }
        //Obtiene todas las preguntas de la base de Datos
        bateriaPreguntas = pantalla.ObtenerBateriaPreguntas(adaptadorDB);

        //Pinta las preguntas y las respuesatas;
        mostrarDatos(seleccionar_pregunta);

        //Acciones de los distintos botones: Cada boton corresponde a una respuesta;
        opcion1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Context context = getApplicationContext();
                seleccion = opcion1.getText().toString();
                //Lógica si has acertado o por el contrario has errado en la pregunta
                if (seleccion == correcta) {
                    //dialog.getDialog().setTitle("Acertado");
                    numeroAciertos++;
                    dialogoResultadoPositivo.showDialogPositivo(fm, dialogoResultadoPositivo);
                    objSonido.reproduccionSonidoAcertada(context);
                    seleccionar_pregunta++;
                    //Función para saber si has llegado al final de las respuestas o no
                    GameFinal(seleccionar_pregunta);
                } else {
                    //dialog.getDialog().setTitle("No Acertado");
                    numeroErrores++;
                    dialogoResultadoNegativo.showDialogNegativo(fm, dialogoResultadoNegativo, numeroAciertos, numeroErrores, numeroPartida);
                    objSonido.reproduccionSonidoErronea(context);
                    seleccionar_pregunta++;
                    //Función para saber si has llegado al final de las respuestas o no
                    GameFinal(seleccionar_pregunta);

                }
            }
        });

        opcion2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                seleccion = opcion2.getText().toString();
                if (seleccion == correcta) {
                 //   dialog.getDialog().setTitle("Acertado");
                    numeroAciertos++;
                    dialogoResultadoPositivo.showDialogPositivo(fm, dialogoResultadoPositivo);
                    seleccionar_pregunta++;
                    objSonido.reproduccionSonidoAcertada(context);
                    GameFinal(seleccionar_pregunta);
                } else {
                 //   dialog.getDialog().setTitle("No Acertado");
                    numeroErrores++;
                    dialogoResultadoNegativo.showDialogNegativo(fm, dialogoResultadoNegativo, numeroAciertos, numeroErrores, numeroPartida);
                    seleccionar_pregunta++;
                    objSonido.reproduccionSonidoErronea(context);
                    GameFinal(seleccionar_pregunta);
                }
            }
        });

        opcion3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                seleccion = opcion3.getText().toString();
                if (seleccion == correcta) {
                //    dialog.getDialog().setTitle("Acertado");
                    numeroAciertos++;
                    dialogoResultadoPositivo.showDialogPositivo(fm, dialogoResultadoPositivo);
                    seleccionar_pregunta++;
                    objSonido.reproduccionSonidoAcertada(context);
                    GameFinal(seleccionar_pregunta);
                } else {
                    numeroErrores++;
                    dialogoResultadoNegativo.showDialogNegativo(fm, dialogoResultadoNegativo, numeroAciertos, numeroErrores, numeroPartida);
                    seleccionar_pregunta++;
                    objSonido.reproduccionSonidoErronea(context);
                    GameFinal(seleccionar_pregunta);
                }
            }
        });

        opcion4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                seleccion = opcion4.getText().toString();
                if (seleccion == correcta) {
                    numeroAciertos++;
                    dialogoResultadoPositivo.showDialogPositivo(fm, dialogoResultadoPositivo);
                    seleccionar_pregunta++;
                    objSonido.reproduccionSonidoAcertada(context);
                    GameFinal(seleccionar_pregunta);
                } else {
                    numeroErrores++;
                    dialogoResultadoNegativo.showDialogNegativo(fm, dialogoResultadoNegativo, numeroAciertos, numeroErrores, numeroPartida);
                    seleccionar_pregunta++;
                    objSonido.reproduccionSonidoErronea(context);
                    GameFinal(seleccionar_pregunta);
                    }
                }
            });



    }

    public void GameFinal(int seleccionar_pregunta){
        if (seleccionar_pregunta >= pantalla.getNumero_preguntas()) {
            dialogoResultadoFinal.showDialogResultado(fm, dialogoResultadoFinal, numeroAciertos, numeroErrores, numeroPartida);
            //insertarDatosResultados(numeroPartida, numeroAciertos, numeroErrores);
        }
        else{
            mostrarDatos(seleccionar_pregunta);
        }
    }

    public void mostrarDatos(int posicion_elemento) {
        String tipo_pregunta = CreacionPantallaPregunta(posicion_elemento);
        CreacionFindByIDElementos();
        SetElementosView();
        SeleccionarTipoPregunta(tipo_pregunta);
        numero_pregunta ++;
    }

    public String CreacionPantallaPregunta(int posicion_elemento){
        String tipo_pregunta = new String();
        EstructuraDatos StrucDate = new EstructuraDatos();
        tipo_pregunta = StrucDate.GetTipoPregunta(bateriaPreguntas.get(posicion_elemento));
        correcta = StrucDate.GetRespuestaCorrecta(bateriaPreguntas.get(posicion_elemento));
        vectorPreguntas = bateriaPreguntas.get(posicion_elemento);
        vectorRespuestas = StrucDate.EliminarPregunta(bateriaPreguntas.get(posicion_elemento));
        vectorRespuestas = StrucDate.OrganizarRespuestas(vectorRespuestas);
        return tipo_pregunta;
    }

    public void CreacionFindByIDElementos(){
        imagen = (ImageView) findViewById(R.id.imagenPregunta);
        TextView_numeroPregunta = (TextView)findViewById(R.id.numero_pregunta);
        pregunta = (TextView) findViewById(R.id.pregunta);
        opcion1 = (Button) findViewById(R.id.opcion_1);
        opcion2 = (Button) findViewById(R.id.opcion_2);
        opcion3 = (Button) findViewById(R.id.opcion_3);
        opcion4 = (Button) findViewById(R.id.opcion_4);
    }

    public void SetElementosView(){
        TextView_numeroPregunta.setText(numero_pregunta + ".");
        pregunta.setText(vectorPreguntas.get(0).toString());
        opcion1.setText(vectorRespuestas.get(0).toString());
        opcion2.setText(vectorRespuestas.get(1).toString());
        opcion3.setText(vectorRespuestas.get(2).toString());
        opcion4.setText(vectorRespuestas.get(3).toString());
    }

    public void SeleccionarTipoPregunta(String tipoPregunta){
        if (tipoPregunta.equals("1")){
            objSonido.seleccionArchivoSonidoPregunta(context, correcta);
            imagen.setVisibility(View.GONE);
        }
        else if (tipoPregunta.equals("2")){
            String nombre_imagen = correcta.toLowerCase().replace(" ","");
            int id_imagen =  context.getResources().getIdentifier("drawable/" + nombre_imagen, null, context.getPackageName());
            imagen = (ImageView) findViewById(R.id.imagenPregunta);
            imagen.setImageResource(id_imagen);
            imagen.setVisibility(View.VISIBLE);
        }
        else{
            imagen.setVisibility(View.GONE);
        }
    }
     public Vector<Integer>  insertarDatosResultados(int pregunta, int numeroAciertos, int numeroErrores){
        Vector<Integer> nuevaFila = new Vector<>();
        nuevaFila.add(pregunta);
        nuevaFila.add(numeroAciertos);
        nuevaFila.add(numeroErrores);

        return nuevaFila;
    }

}
