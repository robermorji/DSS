package com.example.roberto.quizz;

import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by roberto on 16/01/2016.
 */
public class OpcionesJuego implements OpcionesGenerales {

    private final int numero_preguntas = 15;
    int  pregunta_aleatoria;
    OpcionesJuego(){

    }

    int getNumero_preguntas() {
       return this.numero_preguntas;
    }

    ArrayList <Vector> ObtenerBateriaPreguntas(AdaptadorDB adaptadorDB){
        ArrayList<Vector> vector = new ArrayList<>();
        vector = adaptadorDB.getPreguntasRespuesta(numero_preguntas);

        return vector;
    }


}
