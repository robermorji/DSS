package com.example.roberto.quizz;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;


public class MainActivity extends AppCompatActivity {

    Button iniciar_juego;
    Button resultados;
    Button enlazarjuego;
    Intent intent;
    int numero_partida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intent = getIntent();
        Bundle bundle = intent.getExtras();
        ArrayList<Vector> total = new ArrayList<>();
        if (bundle != null) {
            numero_partida = bundle.getInt("NumeroPartida");

        }
         Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        iniciar_juego = (Button)findViewById(R.id.game_init);
        iniciar_juego.setOnClickListener(new View.OnClickListener(){
           public void onClick(View view){
               intent = new Intent(getApplicationContext(),ActivityPantallaJuego.class);
               numero_partida ++;
               intent.putExtra("numero_partida",numero_partida);
               startActivity(intent);
               finish();
               System.out.println("IniciarJuego");
           }
        });

        resultados = (Button)findViewById(R.id.resultados);
        resultados.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                intent = new Intent(getApplicationContext(),ActivityPantallaResultado.class);
                startActivity(intent);
                finish();
                System.out.println("Resultados Juego");
            }
        });

       enlazarjuego = (Button)findViewById(R.id.enlazarjuego);
        enlazarjuego.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("http://www.androidgratisfull.com/"));
                startActivity(intent);
                finish();
                System.out.println("EnlazarJuego");
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
