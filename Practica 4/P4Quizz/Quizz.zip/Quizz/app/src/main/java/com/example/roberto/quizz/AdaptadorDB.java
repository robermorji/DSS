package com.example.roberto.quizz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by roberto on 16/01/2016.
 */
public class AdaptadorDB {

    //Nombre de la base de Datos
   // private static final String BBDD = "quizz";
    //Nombre de las tablas
   // private static final String TABLE_NAME = "questions";
   // private static final String TABLE_NAME_RESULT = "resultados";
    //Parámetros  de las tablas
   // private static final String BD_ID = "_id";
   // private static final String PREGUNTA = "pregunta";
   // private static final String CORRECTA = "correcta";
   // private static final String OPCION2 = "opcion2";
   // private static final String OPCION3 = "opcion3";
   // private static final String OPCION4 = "opcion4";

   // private static final String ID_LOG = "Uso de BD";

   // private static final int VERSION_DB = 1;
    private final Context context;

    private SQLiteDatabase bdatos;
    private BDHelper AuxBD;


    AdaptadorDB(Context context) {
        this.context = context;
        AuxBD = new BDHelper(this.context);
    }

    public AdaptadorDB open() throws SQLException {
        bdatos = AuxBD.getWritableDatabase();
        return this;
    }

    public void close() {
        AuxBD.close();
    }

   public ArrayList<Vector> getPreguntasRespuesta(int limite) {
        Vector <String> auxiliar = new Vector<>();
        ArrayList<Vector> vectorString = new ArrayList<>();
        Cursor cursor;
        bdatos = AuxBD.getReadableDatabase();

        cursor = bdatos.rawQuery("SELECT questions,correcta,opcion2,opcion3,opcion4,pregunta_tipo FROM preguntas ORDER BY RANDOM() LIMIT ?;", new String[]{String.valueOf(limite)});

        while(cursor.moveToNext()) {
            auxiliar.add(0,cursor.getString(0));
            auxiliar.add(1, cursor.getString(1));
            auxiliar.add(2, cursor.getString(2));
            auxiliar.add(3, cursor.getString(3));
            auxiliar.add(4, cursor.getString(4));
            auxiliar.add(5, cursor.getString(5));
            vectorString.add(auxiliar);
            auxiliar = new Vector<>();
        }
        return vectorString;
    }

    public Vector<String> getPreguntasText(int numero_pregunta) {
        Vector<String> auxiliar = new Vector<>();
        Cursor cursor;
        bdatos = AuxBD.getReadableDatabase();

        cursor = bdatos.rawQuery("SELECT questions FROM preguntas WHERE _id==" + numero_pregunta + ";", null);
        while(cursor.moveToNext()) {
            auxiliar.add(0,cursor.getString(0));
        }
        return auxiliar;
    }

    public Vector<String> getRespuestasText(int numero_pregunta) {
        ArrayList<Vector> resultado = new ArrayList<>();
        Vector<String> auxiliar = new Vector<>();
        Cursor cursor;
        bdatos = AuxBD.getReadableDatabase();
        cursor = bdatos.rawQuery("SELECT correcta,opcion2,opcion3,opcion4 FROM preguntas WHERE _id==" + numero_pregunta + ";", null);

        for (int i=0;cursor.moveToNext();i++) {
            auxiliar.add(i,cursor.getString(0));
            auxiliar.add(i,cursor.getString(1));
            auxiliar.add(i,cursor.getString(2));
            auxiliar.add(i,cursor.getString(3));
        }
        return auxiliar;
    }

     public void createTable(){
        bdatos = AuxBD.getWritableDatabase();
        AuxBD.onCreate(bdatos);
    }

    /**
     * @return Número de elementos de mi tabla preguntas
     *
     */
    public int AllDB(){
        int num_elem = 0;
        bdatos = AuxBD.getReadableDatabase();
        Cursor cursor = bdatos.rawQuery("SELECT * FROM preguntas;", null);
        while ( cursor.moveToNext()){
            num_elem ++;
        }

        return num_elem;
    }

    public void InsertarResultados(int aciertos, int errores, int numerojuego){
        bdatos = AuxBD.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("pregunta",numerojuego);
        values.put("aciertos", aciertos);
        values.put("fallos", errores);
        bdatos.insert("resultado",null,values);
    }

    public ArrayList<Vector> GetResultados(){
        Vector<String> auxiliar = new Vector<>();
        ArrayList<Vector> resultado = new ArrayList<>();
        bdatos = AuxBD.getReadableDatabase();
        Cursor cursor = bdatos.rawQuery("SELECT * FROM resultado;", null);
        while ( cursor.moveToNext()){
            auxiliar.add(0,cursor.getString(0));
            auxiliar.add(1,cursor.getString(1));
            auxiliar.add(2,cursor.getString(2));
            resultado.add(auxiliar);
            auxiliar = new Vector<>();
        }

        return resultado;
    }


}