package com.example.roberto.quizz;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Vector;

public class ActivityPantallaResultado extends AppCompatActivity {
    AdaptadorDB db;
    ArrayList<Vector> resultados;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        resultados = new ArrayList<>();
        this.context = getApplicationContext();
        db = new AdaptadorDB(context);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_pantalla_resultado);

        resultados = db.GetResultados();
        for (int num_filas=0; num_filas<resultados.size();num_filas++)
            creacionFilasLayout(num_filas);
    }

    public void creacionFilasLayout(int num_filas){
        TableLayout tabla = (TableLayout)findViewById(R.id.tableLayoutMean);
        TableRow fila;
        TableRow.LayoutParams layoutFila;

        TextView numeroPartida;
        TextView aciertos;
        TextView fallos;

        layoutFila = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT);
        fila = new TableRow(this);
        fila.setLayoutParams(layoutFila);

        numeroPartida = new TextView(this);
        aciertos = new TextView(this);
        fallos = new TextView(this);

        numeroPartida.setText(resultados.get(num_filas).get(0).toString());
        aciertos.setText(resultados.get(num_filas).get(1).toString());
        fallos.setText(resultados.get(num_filas).get(1).toString());

        fila.addView(numeroPartida);
        fila.addView(aciertos);
        fila.addView(fallos);
        tabla.addView(fila);
    }
}
